#!bin/bash
F=test; cat $F.in; ./parse $F.in
