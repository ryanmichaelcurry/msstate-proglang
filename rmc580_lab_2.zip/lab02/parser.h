/*
Complete this file header...

*/

extern int nextToken;

// Function forward declarations
int lex();
void sentence();
